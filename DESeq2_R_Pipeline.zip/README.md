# DESeq2 R Pipeline

This repository contains scripts and data for RNA-seq differential expression analysis using DESeq2.

## Directory Structure

- `data/`: Contains input CSV files (count data and metadata)
- `scripts/`: Contains R scripts for DESeq2 analysis
- `results/`: Contains output PDF files (plots and visualizations) 